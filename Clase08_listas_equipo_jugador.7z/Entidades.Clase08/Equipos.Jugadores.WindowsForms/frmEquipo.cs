﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades.Clase08;

namespace Equipos.Jugadores.WindowsForms
{
    public partial class frmEquipo : Form
    {
        private Equipo _equipo;

        public frmEquipo()
        {
            InitializeComponent();
        }

        private void frmEquipo_Load(object sender, EventArgs e)
        {

        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            string nombre = txtNombre.Text;
            short cantJugadores = short.Parse(txtCantJugadores.Text);

            _equipo = new Equipo(cantJugadores, nombre);
            btnAceptar.Visible = false;
            btnCancelar.Visible = false;
            txtCantJugadores.Enabled = false;
            txtNombre.Enabled = false;
            lstEquipo.Visible = true;
            btnAgregar.Visible = true;
        }
    }
}
